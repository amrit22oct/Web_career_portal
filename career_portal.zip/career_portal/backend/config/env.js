// config/env.js
import dotenv from 'dotenv';
dotenv.config();
